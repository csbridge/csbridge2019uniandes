
/**
 * Creative
 * -----
 * Make any console program you like!
 */
public class Creative extends EsConsole {

	public void run() {
		// your code here...
	}

}
