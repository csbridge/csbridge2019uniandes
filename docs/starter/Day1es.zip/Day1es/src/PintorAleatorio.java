
public class PintorAleatorio extends EsKarel {
	
	public void run() {
		// tu codigo va aca...
	}

}
