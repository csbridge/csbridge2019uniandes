import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;
import java.awt.Color;

public class MultipleBalls extends EsGraphics {
	
	public void run() {
		// your code here...
	}
	
}
