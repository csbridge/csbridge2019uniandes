
/**
 * Hola Mundo
 * -----
 * Un clásico
 */
public class HolaMundo extends EsConsole {

	public void run() {
		imprimir("Hola mundo");
	}

}
