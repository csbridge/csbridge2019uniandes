
public class RecogerPeriodico extends EsKarel {
	
	public void run(){
		// tu codigo va aca...
	}
}
