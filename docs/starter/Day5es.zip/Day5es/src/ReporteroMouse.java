import java.awt.Color;
import java.awt.event.MouseEvent;

import espl.*;

public class ReporteroMouse extends EsGraphics {

	public void run() {
		// tu codigo aca
	}
	
	public void mouseMovido(MouseEvento e) {
		// tu codigo aca
	}
}
