

/**
 * SomeSum
 * -----
 * Write a program that reads in 10 integers 
 * from the user and then outputs the sum of the entered values
 */
public class SomeSum extends EsConsole {

	public void run() {
		// your code here...
	}

}
