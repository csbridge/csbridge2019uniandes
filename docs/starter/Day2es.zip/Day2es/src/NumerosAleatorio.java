
/**
 * Numeros Aleatorio
 * -----
 * Imprime 1,000 números al azar entre 0 y 100.
 */
public class NumerosAleatorio extends EsConsole {
	

	public void run() {
		// cambiar este codigo para imprimir 1000 
		// numeros aleatorios en el rango de 0 a 100.	
		int ejemplo = intAleatorio(0, 100);
		imprimir(ejemplo);	
	}
}
