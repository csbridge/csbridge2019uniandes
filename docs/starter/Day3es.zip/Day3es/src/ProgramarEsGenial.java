import graphics.EsGraphics;
import graphics.*;

public class ProgramarEsGenial extends EsGraphics {
	
	public void run() {
		// tu cogido va aca...
	}

}
