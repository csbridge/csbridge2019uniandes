
/**
 * Numero Favorito
 * -----
 * Un usuario intenta adivinar tu numero favorito.
 */
public class NumeroFavorito extends EsConsole {

	// esta es una constante en Java
	// cambia esto para que sea tu número favorito
	private static final int NUMERO_FAVORITO = 0;
	
	public void run() {
		// tu codigo va aca...	
	}

}
