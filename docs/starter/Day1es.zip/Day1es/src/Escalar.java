
public class Escalar extends EsKarel {
	
	public void run() {
		// tu codigo va aca...
	}

}
