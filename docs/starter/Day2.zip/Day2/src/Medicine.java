
/**
 * Medicine
 * -------------
 * This program creates unique and hard to predict numbers that can be
 * put on packages of real medicine. People who buy the medicine can
 * text message the number on their package to tell if its real.
 */
public class Medicine extends EsConsole {
	
	private static final int NUM_PACKAGES = 1000;
	
	public void run() {
		// your code here
	}

}
