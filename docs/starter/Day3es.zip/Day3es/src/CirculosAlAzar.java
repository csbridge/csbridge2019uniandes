import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;


/**
 * Circulos Al Azar
 * --------------
 * Dibuja 10 círculos al azar de modo que cada círculo esté en la pantalla.
 */
public class CirculosAlAzar extends EsGraphics {
	 
    private static final int N_CIRCULOS = 10;
 
    public void run() {
        // tu codigo aca
    }
 
}