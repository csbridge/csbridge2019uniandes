import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;
import graphics.EsGraphics;
import graphics.*;
import java.awt.*;


/**
 * Dibuja un Cuadrado de Misterio que cambia de color.
 */
public class CuadradoMisterioso extends EsGraphics {

	private static final int TAMANO = 100;
    private static final int RETRASAR = 1000;
	
	public void run() {
		// tu codigo aca
	}
}