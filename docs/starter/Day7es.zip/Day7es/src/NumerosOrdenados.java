import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import acm.graphics.GMath;
import acm.graphics.GRect;
import acm.program.ConsoleProgram;
import espl.EsConsole;


public class NumerosOrdenados extends EsConsole{
	
	public void run() {
		// tu codigo aca.
	}

}
