import stanford.karel.*;

public class InvertBeepers extends SuperKarel {
	
	public void run() {
		// your code here...
	}
}
