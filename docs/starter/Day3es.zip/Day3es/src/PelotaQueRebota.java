import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;

public class PelotaQueRebota extends EsGraphics {
	
	public void run() {
		// Your code here...
	}

}
