import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;
import java.awt.Color;

public class Objetivo extends EsGraphics {

	private static final int RADIO_CIRCULO_GRANDE = 150;
	private static final int RADIO_CIRCULO_MEDIO = 100;
	private static final int RADIO_CIRCULO_PEQUENO = 50;
	
	public void run() {
		// tu cogido va aca...
		// asegurate de usar metodos!
	}

}