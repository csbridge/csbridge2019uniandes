
public class PuntoMedio extends EsKarel {
	public void run() {
		// tu codigo va aca...
	}
}

