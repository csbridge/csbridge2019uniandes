import graphics.EsConsole;

public class Liftoff extends EsConsole {

	public void run() {
	    // tu codigo va aca
	}
}