/*
 * File: ProyectoFinal.java
 * ------------------------
 * Explica tu proyecto aca.
 */
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.*;

import espl.*;

public class ProyectoFinal extends EsGraphics {
	
	/**********************************************
	 *                 Constantes                 *
	 **********************************************/

	/* No cambies el nombre de estos constantes.
	 * Estos constantes controllan el tamano del canvas.
	 */
	public static final int APPLICATION_WIDTH = 400;
	public static final int APPLICATION_HEIGHT = 500;

	/**********************************************
	 *                 Atributos                  *
	 **********************************************/
	// Tus atributos aqui.

	public void run() {
		/* logre :) */
	}

}