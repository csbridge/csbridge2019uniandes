/*
 * File: Breakout.java
 * -------------------
 * Name:
 * Section Leader:
 * 
 * This file will eventually implement the game of Breakout.
 */
import java.awt.Color;
import espl.*;

public class Escaparse extends EsGraphics {
	
	/**********************************************
	 *        Constantes que puedes usar          *
	 **********************************************/

	/** Width and height of application window in pixels */
	public static final int APPLICATION_WIDTH = 400;
	public static final int APPLICATION_HEIGHT = 600;

	/** Constantes para la barra */
	private static final int BARRA_ANCHO = 60;
	private static final int BARRA_ALTURA = 10;
	private static final int BARRA_Y_OFFSET = 30;

	/** Constantes para las filas */
	private static final int NBLOQUES_POR_FILA = 10;
	private static final int NFILAS = 10;

	/** Constantes para las bloques */
	private static final int BLOQUE_SEP = 4;
	private static final int BLOQUE_ANCHO =
			(APPLICATION_WIDTH - (NBLOQUES_POR_FILA - 1) * BLOQUE_SEP) / NBLOQUES_POR_FILA;
	private static final int BLOQUE_ALTURA = 8;
	private static final int BLOQUE_Y_OFFSET = 70;
	
	/** Constantes para la pelota */
	private static final int PELOTA_RADIO = 10;

	/** Numero de turnos */
	private static final int NTURNOS = 3;
	
	/** Retraso de la animación o tiempo de pausa entre movimientos de la pelota. */	
	private static final int RETRASO = 10;

	public void run() {
		imprimir("funciona");
	}
	
	
}