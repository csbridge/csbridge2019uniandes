
/**
 * Hello World
 * -----
 * The classic
 */
public class HolaMundo extends EsConsole {

	public void run() {
		imprimir("Hola mundo");
	}

}
