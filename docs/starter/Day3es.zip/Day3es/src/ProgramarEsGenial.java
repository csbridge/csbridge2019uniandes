import graphics.EsGraphics;

import java.awt.Color;

import graphics.*;

public class ProgramarEsGenial extends EsGraphics {
	
	public void run() {
		Color x = Color.RED;
	}

}
