import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;
import java.awt.Color;

public class Cortometraje extends EsGraphics {

	public void run() {
		// animar una pelicula!
	}

}