import stanford.karel.*;

public class UNKarel extends SuperKarel {
	
	public void run() {
		// your code goes here...
	}
	
}
	