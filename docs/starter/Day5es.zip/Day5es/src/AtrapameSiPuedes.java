import acm.program.*;
import acm.graphics.*;
import acm.util.*;
import espl.*;
import java.awt.Color;
import java.awt.event.*;

public class AtrapameSiPuedes extends EsGraphics {
	private static final double TAMANO_FURTIVO = 60;
	private static final double TAMANO_DISTRACTOR = 50;
	private static final double N_DISTRACTORES = 20;
	
	public void run() {
		// tu codigo aca
	}

}
