
/**
 * Nimm
 * -----
 * Runs a two player version of the ancient game of Nimm.
 */
public class Nimm extends EsConsole {

	public void run() {
		// your code here...
		
	}

}
