
/**
 * Medicina
 * -------------
 * Este programa crea numeros unicos y dificiles 
 * de predecir que se pueden colocar en paquetes 
 * de medicamentos reales. Las personas que compran 
 * el medicamento pueden enviar un mensaje de texto 
 * al número de su paquete para saber si es real.
 */
public class Medicina extends EsConsole {
	
	private static final int NUM_PAQUETAS = 1000;
	
	public void run() {
		// tu codigo va aca...
	}

}
