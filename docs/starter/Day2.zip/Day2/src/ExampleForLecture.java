
/**
 * Random Numbers
 * -----
 * Prints 1,000 random numbers between 0 and 100
 */
public class ExampleForLecture extends EsConsole {
	

	public void run() {
		setFont("Courier-24");	
		int example = intAleatorio(0, 100);
		println(example);	
	}
}
