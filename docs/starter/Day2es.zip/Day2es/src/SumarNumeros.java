

/**
 * SumarNumeros
 * -----
 * Escriba un programa que lea en 10 enteros 
 * del usuario y luego genere la suma de los 
 * valores ingresados
 */
public class SumarNumeros extends EsConsole {

	public void run() {
		// tu codigo va aca...	
	}

}
