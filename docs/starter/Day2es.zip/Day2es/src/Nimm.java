
/**
 * Nimm
 * -----
 * Ejecuta una version para dos jugadores del 
 * antiguo juego de Nimm.
 */
public class Nimm extends EsConsole {

	public void run() {
		// tu codigo va aca...	
	}

}
