
/**
 * Random Numbers
 * -----
 * Prints 1,000 random numbers between 0 and 100
 */
public class RandomNumbers extends EsConsole {
	

	public void run() {
		// change this code to print 1000 random numbers
		// in the range 0 to 100.	
		int example = intAleatorio(0, 100);
		println(example);	
	}
}
