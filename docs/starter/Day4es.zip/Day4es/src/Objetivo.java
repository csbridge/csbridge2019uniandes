import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;
import java.awt.Color;

public class Objetivo extends EsGraphics {

	private static final int CIRCULO_GRANDE_RADIO = 150;
	private static final int CIRCULO_MEDIO_RADIO = 100;
	private static final int CIRCULO_PEQUENO_RADIO = 50;
	
	public void run() {
		// tu cogido va aca...
		// asegurate de usar metodos!
	}

}