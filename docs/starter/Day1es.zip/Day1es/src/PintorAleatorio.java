
public class PintorAleatorio extends EsKarel {
	
	public void run() {
		// ejemplo:
		pintarEsquina(BLUE);
		
	}

}
