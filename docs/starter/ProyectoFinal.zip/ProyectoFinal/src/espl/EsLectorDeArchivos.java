package espl;

import java.io.*;
import java.util.*;

public class EsLectorDeArchivos {
	String nombreDeArchivo;

	public EsLectorDeArchivos(String nombreDeArchivo) {
		this.nombreDeArchivo = nombreDeArchivo;
	}

	public ArrayList<String> leerPalabras() {
		ArrayList<String> palabras = new ArrayList<String>();
		try {
			Scanner archivoLector = new Scanner(new File(this.nombreDeArchivo));
			while (archivoLector.hasNext()){
			    palabras.add(archivoLector.next());
			}
			archivoLector.close();
			return palabras;
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
			return palabras;
		}
	}

	public ArrayList<String> leerLineas() {		
		ArrayList<String> lineas = new ArrayList<String>();
		try {
			Scanner archivoLector = new Scanner(new File(this.nombreDeArchivo));
			while (archivoLector.hasNextLine()){
				lineas.add(archivoLector.nextLine());
			}
			archivoLector.close();
			return lineas;
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
			return lineas;
		} 
	}
	
}

