/**
 * Luna
 * -----
 * Convierte el peso en la tierra en peso en la luna.
 */
public class Luna extends EsConsole {

	public void run() {
		// tu codigo va aca...
	}

}
