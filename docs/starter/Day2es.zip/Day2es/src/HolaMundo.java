
/**
 * Hola Mundo
 * -----
 * Un clásico
 */
public class HolaMundo extends EsConsole {

	public void run() {
		// tu codigo va aca
	}

}
