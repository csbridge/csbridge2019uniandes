
public class Poner100 extends EsKarel {
	
	public void run() {
		// tu codigo va aca...
	}

}
