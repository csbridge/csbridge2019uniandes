import stanford.karel.*;

public class Place100 extends SuperKarel {
	
	public void run() {
		// your code here...
	}

}
