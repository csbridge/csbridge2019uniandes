
/**
 * Favorite Number
 * -----
 * A user tries to guess your favorite number
 */
public class NumeroFavorito extends EsConsole {

	// change this to be your favorite number
	private static final int FAVORITE_NUMBER = 0;
	
	public void run() {
		// your code here..
	}

}
