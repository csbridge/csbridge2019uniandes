import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;
import java.awt.Color;
/**
 * Cuidada: Este es un bono! Solo debes hacerlo 
 * si terminas la Ilusiones1..
 */
public class Ilusion2 extends EsGraphics {
	
	public static final int APPLICATION_WIDTH = 800;
	public static final int APPLICATION_HEIGHT = 520;
	
	private static final int ALTO_FILA = 50;
	private static final int N_FILAS = 10;
	
	public void run() {
		// tu codigo va aca...
	}
}
