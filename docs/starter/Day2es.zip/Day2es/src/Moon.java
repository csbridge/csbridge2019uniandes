/**
 * Moon
 * -----
 * Converts weight on earth into weight on the mooon.
 */
public class Moon extends EsConsole {

	public void run() {
		// your code here...
	}

}
