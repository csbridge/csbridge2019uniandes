import espl.*;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;


public class LaLinea extends EsGraphics {

	public void run() {
		// tu codigo aca...
	}

}
