import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;
import java.awt.Color;

public class CreativeStringArt extends EsGraphics {
	
	public void run() {
		// Your code here...
		// Anything you want!
	}

}
