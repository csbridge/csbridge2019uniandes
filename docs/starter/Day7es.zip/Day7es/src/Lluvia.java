import java.util.ArrayList;
import espl.*;

public class Lluvia extends EsGraphics {

	public void run() {
		// tu codigo aca...
	}

}