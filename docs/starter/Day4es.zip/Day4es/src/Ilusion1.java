import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;
import java.awt.Color;

public class Ilusion1 extends EsGraphics {
	/* Estas constantes le dicen al programa de graficos 
	 * lo grande que debe ser. Puedes ignorarlos. */
	public static final int APPLICATION_WIDTH = 540;
	public static final int APPLICATION_HEIGHT = 560;
	
	/* El tamano de cada dimension del cuadrado. */
	private static final int TAMANO = 100;
	
	/* El espacio entre dos casillas */
	private static final int BRECHA = 10;
	
	public void run() {
		// tu codigo va acs.
	}
}
