import graphics.EsConsole;

public class Despegue extends EsConsole {

	public void run() {
	    // tu codigo va aca
	}
}