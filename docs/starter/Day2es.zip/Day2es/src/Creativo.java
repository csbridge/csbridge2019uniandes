
/**
 * Creativo
 * -----
 * Haz cualquier programa de consola que te guste!
 */
public class Creativo extends EsConsole {

	public void run() {
		// your code here...
	}

}
