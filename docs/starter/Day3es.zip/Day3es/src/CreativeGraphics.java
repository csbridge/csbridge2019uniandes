import graphics.EsGraphics;
import graphics.*;
import acm.graphics.*;
import acm.program.*;
import java.awt.Color;

public class CreativeGraphics extends EsGraphics {
	
	public void run() {
		// tu codigo aca...
		// Todo lo que quieras!
	}

}
